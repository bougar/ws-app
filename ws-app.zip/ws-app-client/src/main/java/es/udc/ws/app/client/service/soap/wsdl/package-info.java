@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.ws.app.udc.es/")
package es.udc.ws.app.client.service.soap.wsdl;
